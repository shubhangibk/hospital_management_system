# HOSPITAL MANAGEMENT SYSTEM


#--------------Data Entery frame functions----------------

#-------------operations on doctor ---------
def Doctor():

    def add_doctor():

        Id=d_id.get()
        name=d_name.get()
        qualification=d_qualification.get()
        Department=department.get()
        mobile=d_mob.get()
        email=d_email.get()
        address=d_address.get()
        gender=d_gender.get()
    
        try:
            
            strr = 'insert into doctor values(%s,%s,%s,%s,%s,%s,%s,%s)'
            mycursor.execute(strr ,(Id,name,qualification,Department,mobile,email,address,gender))
            con.commit()
            messagebox.showinfo('Notification','data added succesfully',parent=addroot)
            clear_doctor()
            fetch_data()
            
        except:
            messagebox.showerror('Notifications','Data is not added!',parent=addroot)
    
    def fetch_data():
        mycursor.execute("select * from doctor")
        rows = mycursor.fetchall()
        if len(rows)!=0:
            doctor_table.delete(*doctor_table.get_children())
            for row in rows:
                doctor_table.insert('',END,values=row)
            con.commit()
        

    def get_cursor(a):
        cursor_row = doctor_table.focus()
        contents = doctor_table.item(cursor_row)
        print(contents)
        row=contents['values']
        d_id.set(row[0])
        d_name.set(row[1])
        d_qualification.set(row[2])
        department.set(row[3])
        d_mob.set(row[4])
        d_email.set(row[5])
        d_address.set(row[6])
        d_gender.set(row[7])


    def update_doctor():
        Id = d_id.get()
        name = d_name.get()
        qualification = d_qualification.get()
        Department = department.get()
        mobile = d_mob.get()
        email = d_email.get()
        address = d_address.get()
        gender = d_gender.get()
        
        try:

            mycursor.execute("update doctor set d_name=%s,d_qualification=%s,department=%s,d_mob=%s,d_email=%s,d_address=%s,d_gender=%s where d_id=%s ",(name,qualification,Department,mobile,email,address,gender,Id))
            con.commit()
            messagebox.showinfo('Notification','data updated succesfully',parent=addroot)
            fetch_data()
        except:
            messagebox.showerror('Notifications','Data is not updated!',parent=addroot)
            
        
    def delete_doctor():
        Id = d_id.get()
        name = d_name.get()
        qualification = d_qualification.get()
        Department = department.get()
        mobile = d_mob.get()
        email = d_email.get()
        address = d_address.get()
        gender = d_gender.get()
        mycursor.execute("delete from doctor where d_id=%s",Id)
        con.commit()
        fetch_data()
        clear_doctor()

    def clear_doctor():
        d_id.set("")
        d_name.set("")
        d_qualification.set("")
        department.set("")
        d_mob.set("")
        d_email.set("")
        d_address.set("")
        d_gender.set("")

    def search_doctor():
        Id = d_id.get()
        name = d_name.get()
        qualification = d_qualification.get()
        Department = department.get()
        mobile = d_mob.get()
        email = d_email.get()
        address = d_address.get()
        gender = d_gender.get()
        search_by= d_search_by.get()
        search_txt=d_search_txt.get()

        if(search_by=='ID'):
            strr='select * from doctor where d_id=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                doctor_table.delete(*doctor_table.get_children())
                for row in rows:
                    doctor_table.insert('',END,values=row)
            con.commit()
        elif(search_by=='MOBILE'):
            strr='select * from doctor where d_mob=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                doctor_table.delete(*doctor_table.get_children())
                for row in rows:
                    doctor_table.insert('',END,values=row)
            con.commit()
        else:
            strr='select * from doctor where d_email=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                doctor_table.delete(*doctor_table.get_children())
                for row in rows:
                    doctor_table.insert('',END,values=row)
            con.commit()
            
    #-----------------------doctor root--------------------------------------------------------------------------
    addroot = Toplevel(master=DATA_ENTRY)
    addroot.grab_set()
    addroot.geometry('1350x700+10+10')
    addroot.title('Hospital Management System')
    addroot.config(bg='DarkOrchid1')
    addroot.iconbitmap('hmsicon.ico')
    addroot.resizable(False,False)

    title_lable = Label(addroot,text='DOCTORS ENTRY',width=16,font=('arial',16,'italic bold'),bg='DarkOrchid1')
    title_lable.place(x=400,y=10)

    #----------------------manage frame------------------------------------------------------------------------------
    manage_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    manage_frame.place(x=20,y=90,width=450,height=560)

    id_lable = Label(manage_frame,text='ID:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    id_lable.place(x=10,y=10)
    
    name_lable = Label(manage_frame,text='NAME:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    name_lable.place(x=10,y=70)

    qualification_lable = Label(manage_frame,text='QUALIFICATION:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    qualification_lable.place(x=10,y=130)

    department_lable = Label(manage_frame,text='DEPARTMENT:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    department_lable.place(x=10,y=190)

    mobile_lable = Label(manage_frame,text='MOBILE NO:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    mobile_lable.place(x=10,y=250)

    email_lable = Label(manage_frame,text='EMAIL',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    email_lable.place(x=10,y=310)

    address_lable = Label(manage_frame,text='ADDRESS',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    address_lable.place(x=10,y=370)

    gender_lable = Label(manage_frame,text='GENDER',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    gender_lable.place(x=10,y=430)

    #-------variables----------------------
    d_id = StringVar()
    d_name = StringVar()
    d_qualification = StringVar()
    department = StringVar()
    d_mob = StringVar()
    d_email = StringVar()
    d_address = StringVar()
    d_gender = StringVar()
    d_search_by= StringVar()
    d_search_txt = StringVar()





    id_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=d_id)
    id_entry.place(x=200,y=10)

    name_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=d_name)
    name_entry.place(x=200,y=70)

    qualification_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=d_qualification)
    qualification_entry.place(x=200,y=130)

    department_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=department)
    department_entry.place(x=200,y=190)

    mobile_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=d_mob)
    mobile_entry.place(x=200,y=250)

    email_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=d_email)
    email_entry.place(x=200,y=310)

    address_entry = Entry(manage_frame,font=("roman",15,'bold'),bd=5,textvariable=d_address)
    address_entry.place(x=200,y=360)

    gender_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=d_gender)
    gender_entry.place(x=200,y=430)

    btn_frame=Frame(manage_frame,bd=5,relief=RIDGE,bg='white')
    btn_frame.place(x=5,y=469,width=425,height=50)

    add_doctorbtn = Button(btn_frame,text='ADD',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=add_doctor)
    add_doctorbtn.pack(side=LEFT,expand=True)

    update_doctorbtn = Button(btn_frame,text='UPDATE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=update_doctor)
    update_doctorbtn.pack(side=LEFT,expand=True)

    delete_doctorbtn = Button(btn_frame,text='DELETE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=delete_doctor)
    delete_doctorbtn.pack(side=LEFT,expand=True)

    clear_doctorbtn = Button(btn_frame,text='CLEAR',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=clear_doctor)
    clear_doctorbtn.pack(side=LEFT,expand=True)

    #--------------------detail frame----------------------------------------------------------

    detail_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    detail_frame.place(x=500,y=90,width=800,height=560)

    search_lable = Label(detail_frame,text='search by',width=10,font=('arial',11,'italic bold'),bg='RoyalBlue1')
    search_lable.place(x=10,y=10)

    search_combo = ttk.Combobox(detail_frame,font=('roman',11,'bold'),state='readonly',textvariable=d_search_by)
    search_combo['values']=("ID","MOBILE","EMAIL")
    search_combo.place(x=130,y=10)

    search_txt = Entry(detail_frame,font=('roman',12,'bold'),bd=5,textvariable=d_search_txt)
    search_txt.place(x=300,y=10)
    
    search_doctorbtn = Button(detail_frame,text='SEARCH',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=search_doctor)
    search_doctorbtn.place(x=500,y=10)

    show_doctorbtn = Button(detail_frame,text='SHOW ALL',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=fetch_data)
    show_doctorbtn.place(x=620,y=10)

    #----------------------table frame-----------------------------------------

    table_frame = Frame(detail_frame,bg='white',relief=GROOVE,borderwidth=5)
    table_frame.place(x=10,y=50,width=760,height=500)
    scroll_x = Scrollbar(table_frame,orient=HORIZONTAL)
    scroll_y = Scrollbar(table_frame,orient=VERTICAL)

    doctor_table = ttk.Treeview(table_frame,columns=('d_id','d_name','d_qualification','department','d_mob','d_email','d_address','d_gender'),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
    
    scroll_x.pack(side=BOTTOM,fill=X)
    scroll_y.pack(side=RIGHT,fill=Y)

    scroll_x.config(command=doctor_table.xview)
    scroll_y.config(command=doctor_table.yview)

    doctor_table.heading('d_id',text="ID")
    doctor_table.heading('d_name',text="NAME")
    doctor_table.heading('d_qualification',text="QUALIFICATION")
    doctor_table.heading('department',text="DEPARTMENT")
    doctor_table.heading('d_mob',text="MOBILE")
    doctor_table.heading('d_email',text="EMAIL")
    doctor_table.heading('d_address',text="ADDRESS")
    doctor_table.heading('d_gender',text="GENDER")
    doctor_table['show']='headings'

    doctor_table.column('d_id',width=100)
    doctor_table.column('d_name',width=200)
    doctor_table.column('d_qualification',width=150)
    doctor_table.column('department',width=150)
    doctor_table.column('d_mob',width=100)
    doctor_table.column('d_email',width=150)
    doctor_table.column('d_address',width=200)
    doctor_table.column('d_gender',width=100)
    doctor_table.pack(fill=BOTH,expand=1)
    fetch_data()
    doctor_table.bind('<ButtonRelease-1>',get_cursor)
    
    


       
#---------------------------Patient------------------------------------------------------------------------------------------------------------------
def Patient():

    def add_patient():

        Id = p_id.get()
        name = p_name.get()
        mobile =p_mob.get()
        address = p_address.get()
        disease = p_disease.get()
        dob = p_dob.get()
        age = p_age.get()
        doctor = d_id.get()
        try:

            strr = 'insert into patient values(%s,%s,%s,%s,%s,%s,%s,%s)'
            mycursor.execute(strr ,(Id,name,mobile,address,disease,dob,age,doctor))
            con.commit()
            messagebox.showinfo('Notification','data added succesfully',parent=addroot)
            clear_patient()
            fetch_data()
            
        except:
            messagebox.showerror('Notifications','Data is not added!',parent=addroot)
    
    def fetch_data():
        mycursor.execute("select * from patient")
        rows = mycursor.fetchall()
        if len(rows)!=0:
            patient_table.delete(*patient_table.get_children())
            for row in rows:
                patient_table.insert('',END,values=row)
            con.commit()
        

    def get_cursor(a):
        cursor_row = patient_table.focus()
        contents = patient_table.item(cursor_row)
        print(contents)
        row=contents['values']
        p_id.set(row[0])
        p_name.set(row[1])
        p_mob.set(row[2])
        p_address.set(row[3])
        p_disease.set(row[4])
        p_dob.set(row[5])
        p_age.set(row[6])
        d_id.set(row[7])

    def update_patient():
        Id = p_id.get()
        name = p_name.get()
        mobile =p_mob.get()
        address = p_address.get()
        disease = p_disease.get()
        dob = p_dob.get()
        age = p_age.get()
        doctor = d_id.get()
        try:

            mycursor.execute("update patient set p_name=%s,p_mob=%s,p_address=%s,p_disease=%s,p_dob=%s,p_age=%s,d_id=%s where p_id=%s ",(name,mobile,address,disease,dob,age,doctor,Id))
            con.commit()
            messagebox.showinfo('Notification','data updated succesfully',parent=addroot)
            fetch_data()
        except:
            messagebox.showerror('Notifications','Data is not updated!',parent=addroot)
        
            
    def delete_patient():
        Id = p_id.get()
        name = p_name.get()
        mobile =p_mob.get()
        address = p_address.get()
        disease = p_disease.get()
        dob = p_dob.get()
        age = p_age.get()
        doctor = d_id.get()
        search_by=p_search_by.get()
        search_txt=p_search_txt.get()

        mycursor.execute("delete from patient where p_id=%s",Id)
        con.commit()
        fetch_data()
        clear_patient()

    def clear_patient():
        p_id.set("")
        p_name.set("")
        p_mob.set("")
        p_address.set("")
        p_disease.set("")
        p_dob.set("")
        p_age.set("")
        d_id.set("")

    def search_patient():

        Id = p_id.get()
        name = p_name.get()
        mobile =p_mob.get()
        address = p_address.get()
        disease = p_disease.get()
        dob = p_dob.get()
        age = p_age.get()
        doctor = d_id.get()
        search_by=p_search_by.get()
        search_txt=p_search_txt.get()

        if(search_by=='ID'):
            strr='select * from patient where p_id=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                patient_table.delete(*patient_table.get_children())
                for row in rows:
                    patient_table.insert('',END,values=row)
            con.commit()
        else:
            strr='select * from patient where p_mob=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                patient_table.delete(*patient_table.get_children())
                for row in rows:
                    patient_table.insert('',END,values=row)
            con.commit()
            
    #----------------patient root-----------------------------------------------------   
    addroot = Toplevel(master=DATA_ENTRY)
    addroot.grab_set()
    addroot.geometry('1350x700+10+10')
    addroot.title('Hospital Management System')
    addroot.config(bg='DarkOrchid1')
    addroot.iconbitmap('hmsicon.ico')
    addroot.resizable(False,False)
    
    title_lable = Label(addroot,text='PATIENT ENTRY',width=16,font=('arial',16,'italic bold'),bg='DarkOrchid1')
    title_lable.place(x=400,y=10)

    #----------------------manage frame-----------------------------------
    manage_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    manage_frame.place(x=20,y=90,width=450,height=560)

    id_lable = Label(manage_frame,text='ID:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    id_lable.place(x=10,y=10)
    
    name_lable = Label(manage_frame,text='NAME:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    name_lable.place(x=10,y=70)

    mobile_lable = Label(manage_frame,text='MOBILE:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    mobile_lable.place(x=10,y=130)

    address_lable = Label(manage_frame,text='ADDRESS:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    address_lable.place(x=10,y=190)

    disease_lable = Label(manage_frame,text='DISEASE:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    disease_lable.place(x=10,y=250)

    dob_lable = Label(manage_frame,text='DATE OF BIRTH',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    dob_lable.place(x=10,y=310)

    age_lable = Label(manage_frame,text='AGE',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    age_lable.place(x=10,y=370)

    doctor_lable = Label(manage_frame,text='DOCTOR ID',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    doctor_lable.place(x=10,y=430)
    
    #--------------variables----------------------------------------
    p_id = StringVar()
    p_name = StringVar()
    p_mob = StringVar()
    p_address = StringVar()
    p_disease = StringVar()
    p_dob = StringVar()
    p_age = StringVar()
    d_id = StringVar()
    p_search_by = StringVar()
    p_search_txt = StringVar()

    
    id_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=p_id)
    id_entry.place(x=200,y=10)

    name_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=p_name)
    name_entry.place(x=200,y=70)

    mobile_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=p_mob)
    mobile_entry.place(x=200,y=130)

    address_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=p_address)
    address_entry.place(x=200,y=190)

    disease_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=p_disease)
    disease_entry.place(x=200,y=250)

    dob_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=p_dob)
    dob_entry.place(x=200,y=310)

    age_entry = Entry(manage_frame,font=("roman",15,'bold'),bd=5,textvariable=p_age)
    age_entry.place(x=200,y=360)

    doctor_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=d_id)
    doctor_entry.place(x=200,y=430)

    btn_frame=Frame(manage_frame,bd=5,relief=RIDGE,bg='white')
    btn_frame.place(x=5,y=469,width=425,height=50)

    add_doctorbtn = Button(btn_frame,text='ADD',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=add_patient)
    add_doctorbtn.pack(side=LEFT,expand=True)

    update_doctorbtn = Button(btn_frame,text='UPDATE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=update_patient)
    update_doctorbtn.pack(side=LEFT,expand=True)

    delete_doctorbtn = Button(btn_frame,text='DELETE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=delete_patient)
    delete_doctorbtn.pack(side=LEFT,expand=True)

    clear_doctorbtn = Button(btn_frame,text='CLEAR',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=clear_patient)
    clear_doctorbtn.pack(side=LEFT,expand=True)

    #--------------------detail frame----------------------------------------------------------

    detail_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    detail_frame.place(x=500,y=90,width=800,height=560)

    search_lable = Label(detail_frame,text='search by',width=10,font=('arial',11,'italic bold'),bg='RoyalBlue1')
    search_lable.place(x=10,y=10)

    search_combo = ttk.Combobox(detail_frame,font=('roman',11,'bold'),state='readonly',textvariable=p_search_by)
    search_combo['values']=("ID","MOBILE")
    search_combo.place(x=130,y=10)

    search_txt = Entry(detail_frame,font=('roman',12,'bold'),bd=5,textvariable=p_search_txt)
    search_txt.place(x=300,y=10)
    
    search_doctorbtn = Button(detail_frame,text='SEARCH',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=search_patient)
    search_doctorbtn.place(x=500,y=10)

    show_doctorbtn = Button(detail_frame,text='SHOW ALL',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=fetch_data)
    show_doctorbtn.place(x=620,y=10)

    #----------------------table frame-----------------------------------------

    table_frame = Frame(detail_frame,bg='white',relief=GROOVE,borderwidth=5)
    table_frame.place(x=10,y=50,width=760,height=500)
    scroll_x = Scrollbar(table_frame,orient=HORIZONTAL)
    scroll_y = Scrollbar(table_frame,orient=VERTICAL)

    patient_table = ttk.Treeview(table_frame,columns=('p_id','p_name','p_mob','p_address','p_disease','p_dob','p_age','d_id'),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
    
    scroll_x.pack(side=BOTTOM,fill=X)
    scroll_y.pack(side=RIGHT,fill=Y)

    scroll_x.config(command=patient_table.xview)
    scroll_y.config(command=patient_table.yview)

    patient_table.heading('p_id',text="ID")
    patient_table.heading('p_name',text="NAME")
    patient_table.heading('p_mob',text="MOBILE")
    patient_table.heading('p_address',text="ADDRESS")
    patient_table.heading('p_disease',text="DISEASE")
    patient_table.heading('p_dob',text="D.O.B.")
    patient_table.heading('p_age',text="AGE")
    patient_table.heading('d_id',text="DOCTOR ID")
    patient_table['show']='headings'

    patient_table.column('p_id',width=100)
    patient_table.column('p_name',width=200)
    patient_table.column('p_mob',width=150)
    patient_table.column('p_address',width=150)
    patient_table.column('p_disease',width=100)
    patient_table.column('p_dob',width=150)
    patient_table.column('p_age',width=200)
    patient_table.column('d_id',width=100)
    patient_table.pack(fill=BOTH,expand=1)
    fetch_data()
    patient_table.bind('<ButtonRelease-1>',get_cursor)
    
    


#-----------------------------Inpatient---------------------------------------------------------------------------------------------------------------------------
def Inpatient():
    def add_entry():

        record = In_id.get()
        patient = p_id.get()
        DA = date_of_admission.get()
        DD = date_of_discharge.get()
        room = r_no.get()
        
        try:

            strr = 'insert into inpatient values(%s,%s,%s,%s,%s)'
            mycursor.execute(strr,(record,patient,DA,DD,room))
            con.commit()
            messagebox.showinfo('Notification','data added succesfully',parent=addroot)
            clear_entry()
            fetch_data()
            
        except:
            messagebox.showerror('Notifications','Data is not added!',parent=addroot)
    
    def fetch_data():
        mycursor.execute("select * from inpatient")
        rows = mycursor.fetchall()
        if len(rows)!=0:
            record_table.delete(*record_table.get_children())
            for row in rows:
                record_table.insert('',END,values=row)
            con.commit()
        

    def get_cursor(a):
        cursor_row = record_table.focus()
        contents = record_table.item(cursor_row)
        print(contents)
        row=contents['values']
        In_id.set(row[0])
        p_id.set(row[1])
        date_of_admission.set(row[2])
        date_of_discharge.set(row[3])
        r_no.set(row[4])
        

    def update_entry():
        record = In_id.get()
        patient = p_id.get()
        DA = date_of_admission.get()
        DD = date_of_discharge.get()
        room = r_no.get()
        
        try:

            mycursor.execute("update inpatient set p_id=%s,date_of_admission=%s,date_of_discharge=%s,r_no=%s where In_id=%s ",(patient,DA,DD,room,record))
            con.commit()
            messagebox.showinfo('Notification','data updated succesfully',parent=addroot)
            fetch_data()
        except:
            messagebox.showerror('Notifications','Data is not updated!',parent=addroot)

            
    def delete_entry():
        record = In_id.get()
        patient = p_id.get()
        DA = date_of_admission.get()
        DD = date_of_discharge.get()
        room = r_no.get()

        mycursor.execute("delete from inpatient where In_id=%s",record)
        con.commit()
        fetch_data()
        clear_entry()

    def clear_entry():
        In_id.set("")
        p_id.set("")
        date_of_admission.set("")
        date_of_discharge.set("")
        r_no.set("")
        

    def search_record():

        record = In_id.get()
        patient = p_id.get()
        DA = date_of_admission.get()
        DD = date_of_discharge.get()
        room = r_no.get()
        search_by=i_search_by.get()
        search_txt=i_search_txt.get()

        if(search_by=='RECORD NO'):
            strr='select * from inpatient where In_id=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                record_table.delete(*record_table.get_children())
                for row in rows:
                    record_table.insert('',END,values=row)
            con.commit()
        elif(search_by=='PATIENT ID'):
            strr='select * from inpatient where p_id=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                record_table.delete(*record_table.get_children())
                for row in rows:
                    record_table.insert('',END,values=row)
            con.commit()
        else:
            strr='select * from inpatient where r_no=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                record_table.delete(*record_table.get_children())
                for row in rows:
                    record_table.insert('',END,values=row)
            con.commit()
        
    #---------------------inpatient root-------------------------------------------------------------       
    addroot = Toplevel(master=DATA_ENTRY)
    addroot.grab_set()
    addroot.geometry('1150x600+10+10')
    addroot.title('Hospital Management System')
    addroot.config(bg='DarkOrchid1')
    addroot.iconbitmap('hmsicon.ico')
    addroot.resizable(False,False)

    
    title_lable = Label(addroot,text='INPATIENT ENTRY',width=16,font=('arial',16,'italic bold'),bg='DarkOrchid1')
    title_lable.place(x=400,y=10)
    #----------------------manage frame-------------------------------------------------------------------
    manage_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    manage_frame.place(x=20,y=50,width=460,height=500)

    I_lable = Label(manage_frame,text='RECORD NO:',width=19,font=('arial',13,'italic bold'),bg='RoyalBlue1')
    I_lable.place(x=10,y=10)
    
    P_lable = Label(manage_frame,text='PATIENT ID:',width=19,font=('arial',13,'italic bold'),bg='RoyalBlue1')
    P_lable.place(x=10,y=70)

    DA_lable = Label(manage_frame,text='DATE OF ADMISSION:',width=19,font=('arial',13,'italic bold'),bg='RoyalBlue1')
    DA_lable.place(x=10,y=130)

    DD_lable = Label(manage_frame,text='DATE OF DISCHARGE:',width=19,font=('arial',13,'italic bold'),bg='RoyalBlue1')
    DD_lable.place(x=10,y=190)

    R_lable = Label(manage_frame,text='ROOM NO:',width=19,font=('arial',13,'italic bold'),bg='RoyalBlue1')
    R_lable.place(x=10,y=250)
    
    #---------------------------variables-------------
    In_id = StringVar()
    p_id = StringVar()
    date_of_admission = StringVar()
    date_of_discharge = StringVar()
    r_no = StringVar()
    i_search_by = StringVar()
    i_search_txt = StringVar()

    #---------------------entry field--------------------------------------------------------------
    I_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=In_id)
    I_entry.place(x=230,y=10)

    P_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=p_id)
    P_entry.place(x=230,y=70)

    DA_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=date_of_admission)
    DA_entry.place(x=230,y=130)

    DD_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=date_of_discharge)
    DD_entry.place(x=230,y=190)

    R_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=r_no)
    R_entry.place(x=230,y=250)

    

    btn_frame=Frame(manage_frame,bd=5,relief=RIDGE,bg='white')
    btn_frame.place(x=5,y=390,width=425,height=50)

    add_doctorbtn = Button(btn_frame,text='ADD',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=add_entry)
    add_doctorbtn.pack(side=LEFT,expand=True)

    update_doctorbtn = Button(btn_frame,text='UPDATE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=update_entry)
    update_doctorbtn.pack(side=LEFT,expand=True)

    delete_doctorbtn = Button(btn_frame,text='DELETE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=delete_entry)
    delete_doctorbtn.pack(side=LEFT,expand=True)

    clear_doctorbtn = Button(btn_frame,text='CLEAR',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=clear_entry)
    clear_doctorbtn.pack(side=LEFT,expand=True)

    #--------------------detail frame----------------------------------------------------------

    detail_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    detail_frame.place(x=485,y=50,width=650,height=500)

    search_lable = Label(detail_frame,text='search by:',width=10,font=('arial',10,'italic bold'),bg='RoyalBlue1')
    search_lable.place(x=10,y=10)

    search_combo = ttk.Combobox(detail_frame,font=('roman',10,'bold'),state='readonly',textvariable=i_search_by)
    search_combo['values']=("RECORD NO","PATIENT ID","ROOM NO")
    search_combo.place(x=105,y=10)

    search_txt = Entry(detail_frame,font=('roman',11,'bold'),bd=5,textvariable=i_search_txt)
    search_txt.place(x=255,y=10)
    
    search_doctorbtn = Button(detail_frame,text='SEARCH',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=search_record)
    search_doctorbtn.place(x=444,y=10)

    show_doctorbtn = Button(detail_frame,text='SHOW ALL',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=fetch_data)
    show_doctorbtn.place(x=545,y=10)

    #----------------------table frame-----------------------------------------

    table_frame = Frame(detail_frame,bg='white',relief=GROOVE,borderwidth=5)
    table_frame.place(x=5,y=50,width=630,height=430)
    scroll_x = Scrollbar(table_frame,orient=HORIZONTAL)
    scroll_y = Scrollbar(table_frame,orient=VERTICAL)

    record_table = ttk.Treeview(table_frame,columns=('In_id','p_id','date_of_admission','date_of_discharge','r_no'),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
    
    scroll_x.pack(side=BOTTOM,fill=X)
    scroll_y.pack(side=RIGHT,fill=Y)

    scroll_x.config(command=record_table.xview)
    scroll_y.config(command=record_table.yview)

    record_table.heading('In_id',text="RECORD NO")
    record_table.heading('p_id',text="PATIENT ID")
    record_table.heading('date_of_admission',text="DATE OF ADMISSION")
    record_table.heading('date_of_discharge',text="DATE OF DISCHARGE")
    record_table.heading('r_no',text="ROOM NO")
    record_table['show']='headings'

    record_table.column('In_id',width=100)
    record_table.column('p_id',width=200)
    record_table.column('date_of_admission',width=200)
    record_table.column('date_of_discharge',width=200)
    record_table.column('r_no',width=150)
    record_table.pack(fill=BOTH,expand=1)
    fetch_data()
    record_table.bind('<ButtonRelease-1>',get_cursor)
    





#---------------------------------outpatient---------------------------------------------------------------------------------------------------------
def Outpatient():
    def add_entry():

        record = O_id.get()
        patient = p_id.get()
        DE = date_of_examination.get()
    
        
        try:

            strr = 'insert into outpatient values(%s,%s,%s)'
            mycursor.execute(strr,(record,patient,DE))
            con.commit()
            messagebox.showinfo('Notification','data added succesfully',parent=addroot)
            clear_entry()
            fetch_data()
            
        except:
            messagebox.showerror('Notifications','Data is not added!',parent=addroot)
    
    def fetch_data():

        mycursor.execute("select * from outpatient")
        rows = mycursor.fetchall()
        if len(rows)!=0:
            record_table.delete(*record_table.get_children())
            for row in rows:
                record_table.insert('',END,values=row)
            con.commit()
        

    def get_cursor(a):
        cursor_row = record_table.focus()
        contents = record_table.item(cursor_row)
        print(contents)
        row=contents['values']
        O_id.set(row[0])
        p_id.set(row[1])
        date_of_examination.set(row[2])
        
        
    def update_entry():
        record = O_id.get()
        patient = p_id.get()
        DE = date_of_examination.get()
        
        try:

            mycursor.execute("update outpatient set p_id=%s,date_of_examination=%s  where O_id=%s ",(patient,DE,record))
            con.commit()
            messagebox.showinfo('Notification','data updated succesfully',parent=addroot)
            fetch_data()
        except:
            messagebox.showerror('Notifications','Data is not updated!',parent=addroot)

            
            
    def delete_entry():
        record = O_id.get()
        patient = p_id.get()
        DE = date_of_examination.get()
        search_by=O_search_by.get()
        search_txt=O_search_txt.get()

        mycursor.execute("delete from outpatient where O_id=%s",record)
        con.commit()
        fetch_data()
        clear_entry()

    def clear_entry():
        O_id.set("")
        p_id.set("")
        date_of_examination.set("")
        

    def search_record():

        record = O_id.get()
        patient = p_id.get()
        DE = date_of_examination.get()
        search_by=O_search_by.get()
        search_txt=O_search_txt.get()

        if(search_by=='RECORD NO'):
            strr='select * from outpatient where O_id=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                record_table.delete(*record_table.get_children())
                for row in rows:
                    record_table.insert('',END,values=row)
            con.commit()
        else:
            strr='select * from outpatient where p_id=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                record_table.delete(*record_table.get_children())
                for row in rows:
                    record_table.insert('',END,values=row)
            con.commit()
        
    #---------------------outpatient root-------------------------------------------------------------------------
    addroot = Toplevel(master=DATA_ENTRY)
    addroot.grab_set()
    addroot.geometry('1150x600+10+10')
    addroot.title('Hospital Management System')
    addroot.config(bg='DarkOrchid1')
    addroot.iconbitmap('hmsicon.ico')
    addroot.resizable(False,False)

    title_lable = Label(addroot,text='OUTPATIENT ENTRY',width=16,font=('arial',16,'italic bold'),bg='DarkOrchid1')
    title_lable.place(x=400,y=10)
    #----------------------manage frame----------------------------------------------------------------------------------------------
    manage_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    manage_frame.place(x=20,y=50,width=460,height=500)

    I_lable = Label(manage_frame,text='RECORD NO:',width=19,font=('arial',13,'italic bold'),bg='RoyalBlue1')
    I_lable.place(x=10,y=10)
    
    P_lable = Label(manage_frame,text='PATIENT ID:',width=19,font=('arial',13,'italic bold'),bg='RoyalBlue1')
    P_lable.place(x=10,y=70)

    DE_lable = Label(manage_frame,text='DATE OF EXAMINATION:',width=19,font=('arial',12,'italic bold'),bg='RoyalBlue1')
    DE_lable.place(x=10,y=130)

    #-----------------------variables---------------------------------------------------------------------------------------
    O_id = StringVar()
    p_id = StringVar()
    date_of_examination = StringVar()
    O_search_by = StringVar()
    O_search_txt = StringVar()

    #-------------------entry field-------------------------------------------------------------------------
    I_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=O_id)
    I_entry.place(x=230,y=10)

    P_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=p_id)
    P_entry.place(x=230,y=70)

    DE_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=date_of_examination)
    DE_entry.place(x=230,y=130)

    

    

    btn_frame=Frame(manage_frame,bd=5,relief=RIDGE,bg='white')
    btn_frame.place(x=5,y=390,width=425,height=50)

    add_doctorbtn = Button(btn_frame,text='ADD',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=add_entry)
    add_doctorbtn.pack(side=LEFT,expand=True)

    update_doctorbtn = Button(btn_frame,text='UPDATE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=update_entry)
    update_doctorbtn.pack(side=LEFT,expand=True)

    delete_doctorbtn = Button(btn_frame,text='DELETE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=delete_entry)
    delete_doctorbtn.pack(side=LEFT,expand=True)

    clear_doctorbtn = Button(btn_frame,text='CLEAR',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=clear_entry)
    clear_doctorbtn.pack(side=LEFT,expand=True)

    #--------------------detail frame----------------------------------------------------------

    detail_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    detail_frame.place(x=485,y=50,width=650,height=500)

    search_lable = Label(detail_frame,text='search by:',width=10,font=('arial',10,'italic bold'),bg='RoyalBlue1')
    search_lable.place(x=10,y=10)

    search_combo = ttk.Combobox(detail_frame,font=('roman',10,'bold'),state='readonly',textvariable=O_search_by)
    search_combo['values']=("RECORD NO","PATIENT ID")
    search_combo.place(x=105,y=10)

    search_txt = Entry(detail_frame,font=('roman',11,'bold'),bd=5,textvariable=O_search_txt)
    search_txt.place(x=255,y=10)
    
    search_doctorbtn = Button(detail_frame,text='SEARCH',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=search_record)
    search_doctorbtn.place(x=444,y=10)

    show_doctorbtn = Button(detail_frame,text='SHOW ALL',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=fetch_data)
    show_doctorbtn.place(x=545,y=10)

    #----------------------table frame-----------------------------------------

    table_frame = Frame(detail_frame,bg='white',relief=GROOVE,borderwidth=5)
    table_frame.place(x=5,y=50,width=630,height=430)
    scroll_x = Scrollbar(table_frame,orient=HORIZONTAL)
    scroll_y = Scrollbar(table_frame,orient=VERTICAL)

    record_table = ttk.Treeview(table_frame,columns=('O_id','p_id','date_of_examination'),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
    
    scroll_x.pack(side=BOTTOM,fill=X)
    scroll_y.pack(side=RIGHT,fill=Y)

    scroll_x.config(command=record_table.xview)
    scroll_y.config(command=record_table.yview)

    record_table.heading('O_id',text="RECORD NO")
    record_table.heading('p_id',text="PATIENT ID")
    record_table.heading('date_of_examination',text="DATE OF EXAMINATION")
    record_table['show']='headings'

    record_table.column('O_id',width=100)
    record_table.column('p_id',width=200)
    record_table.column('date_of_examination',width=200)
    record_table.pack(fill=BOTH,expand=1)
    fetch_data()
    record_table.bind('<ButtonRelease-1>',get_cursor)
    





#--------------------------room--------------------------------------------------------------------------------------------------------------------------
def Room():

    def add_room():

        no = r_no.get()
        rtype = r_type.get()
        status = r_status.get()
        nurseid = n_id.get()

        try:

            strr = 'insert into room values(%s,%s,%s,%s)'
            mycursor.execute(strr,(no,rtype,status,nurseid))
            con.commit()
            messagebox.showinfo('Notification','data added succesfully',parent=addroot)
            clear_room()
            fetch_data()
            
        except:
            messagebox.showerror('Notifications','Data is not added!',parent=addroot)
    
    def fetch_data():
        mycursor.execute("select * from room")
        rows = mycursor.fetchall()
        if len(rows)!=0:
            room_table.delete(*room_table.get_children())
            for row in rows:
                room_table.insert('',END,values=row)
            con.commit()
        

    def get_cursor(a):
        cursor_row = room_table.focus()
        contents = room_table.item(cursor_row)
        print(contents)
        row=contents['values']
        r_no.set(row[0])
        r_type.set(row[1])
        r_status.set(row[2])
        n_id.set(row[3])
        


    def update_room():
        no = r_no.get()
        rtype = r_type.get()
        status = r_status.get()
        nurseid = n_id.get()

        
        try:

            mycursor.execute("update room set r_type=%s,r_status=%s,n_id=%s where r_no=%s ",(rtype,status,nurseid,no))
            con.commit()
            messagebox.showinfo('Notification','data updated succesfully',parent=addroot)
            fetch_data()
        except:
            messagebox.showerror('Notifications','Data is not updated!',parent=addroot)

            
            
    def delete_room():
        no = r_no.get()
        rtype = r_type.get()
        status = r_status.get()
        nurseid = n_id.get()

        mycursor.execute("delete from room where r_no=%s",no)
        con.commit()
        fetch_data()
        clear_room()

    def clear_room():
        r_no.set("")
        r_type.set("")
        r_status.set("")
        n_id.set("")
        

    def search_room():

        no = r_no.get()
        rtype = r_type.get()
        status = r_status.get()
        nurseid = n_id.get()
        search_by=r_search_by.get()
        search_txt=r_search_txt.get()

        if(search_by=='ROOM NO'):
            strr='select * from room where r_no=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                room_table.delete(*room_table.get_children())
                for row in rows:
                    room_table.insert('',END,values=row)
            con.commit()
        else:
            strr='select * from room where n_id=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                room_table.delete(*room_table.get_children())
                for row in rows:
                    room_table.insert('',END,values=row)
            con.commit()
            
    #--------------------------room root----------------------------------------------------------------------------  
    addroot = Toplevel(master=DATA_ENTRY)
    addroot.grab_set()
    addroot.geometry('1150x500+10+10')
    addroot.title('Hospital Management System')
    addroot.config(bg='DarkOrchid1')
    addroot.iconbitmap('hmsicon.ico')
    addroot.resizable(False,False)

    title_lable = Label(addroot,text='ROOMS ENTRY',width=16,font=('arial',16,'italic bold'),bg='DarkOrchid1')
    title_lable.place(x=400,y=10)
    #----------------------manage frame---------------------------------------------------------------------------------
    manage_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    manage_frame.place(x=20,y=50,width=450,height=400)

    no_lable = Label(manage_frame,text='ROOM NO:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    no_lable.place(x=10,y=10)
    
    type_lable = Label(manage_frame,text='ROOM TYPE:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    type_lable.place(x=10,y=70)

    status_lable = Label(manage_frame,text='ROOM STATUS:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    status_lable.place(x=10,y=130)

    nurse_lable = Label(manage_frame,text='NURSE ID',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    nurse_lable.place(x=10,y=190)

    
    #-----------variables-----------------------------------------------------------------------------------------------
    r_no = StringVar()
    r_type = StringVar()
    r_status = StringVar()
    n_id = StringVar()
    r_search_by = StringVar()
    r_search_txt = StringVar()


    no_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=r_no)
    no_entry.place(x=200,y=10)

    type_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=r_type)
    type_entry.place(x=200,y=70)

    status_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=r_status)
    status_entry.place(x=200,y=130)

    nurse_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=n_id)
    nurse_entry.place(x=200,y=190)

    

    btn_frame=Frame(manage_frame,bd=5,relief=RIDGE,bg='white')
    btn_frame.place(x=5,y=300,width=425,height=50)

    add_doctorbtn = Button(btn_frame,text='ADD',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=add_room)
    add_doctorbtn.pack(side=LEFT,expand=True)

    update_doctorbtn = Button(btn_frame,text='UPDATE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=update_room)
    update_doctorbtn.pack(side=LEFT,expand=True)

    delete_doctorbtn = Button(btn_frame,text='DELETE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=delete_room)
    delete_doctorbtn.pack(side=LEFT,expand=True)

    clear_doctorbtn = Button(btn_frame,text='CLEAR',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=clear_room)
    clear_doctorbtn.pack(side=LEFT,expand=True)

    #-----------------------detail frame----------------------------------------------------------

    detail_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    detail_frame.place(x=485,y=50,width=650,height=400)

    search_lable = Label(detail_frame,text='search by',width=10,font=('arial',10,'italic bold'),bg='RoyalBlue1')
    search_lable.place(x=10,y=10)

    search_combo = ttk.Combobox(detail_frame,font=('roman',10,'bold'),state='readonly',textvariable=r_search_by)
    search_combo['values']=("ROOM NO","NURSE ID")
    search_combo.place(x=105,y=10)

    search_txt = Entry(detail_frame,font=('roman',11,'bold'),bd=5,textvariable=r_search_txt)
    search_txt.place(x=255,y=10)
    
    search_doctorbtn = Button(detail_frame,text='SEARCH',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=search_room)
    search_doctorbtn.place(x=444,y=10)

    show_doctorbtn = Button(detail_frame,text='SHOW ALL',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=fetch_data)
    show_doctorbtn.place(x=545,y=10)

    #----------------------table frame-----------------------------------------

    table_frame = Frame(detail_frame,bg='white',relief=GROOVE,borderwidth=5)
    table_frame.place(x=5,y=50,width=630,height=330)
    scroll_x = Scrollbar(table_frame,orient=HORIZONTAL)
    scroll_y = Scrollbar(table_frame,orient=VERTICAL)

    room_table = ttk.Treeview(table_frame,columns=('r_no','r_type','r_status','n_id'),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
    
    scroll_x.pack(side=BOTTOM,fill=X)
    scroll_y.pack(side=RIGHT,fill=Y)

    scroll_x.config(command=room_table.xview)
    scroll_y.config(command=room_table.yview)

    room_table.heading('r_no',text="ROOM NO")
    room_table.heading('r_type',text="TYPE")
    room_table.heading('r_status',text="STATUS")
    room_table.heading('n_id',text="NURSE ID")
    room_table['show']='headings'

    room_table.column('r_no',width=100)
    room_table.column('r_type',width=200)
    room_table.column('r_status',width=150)
    room_table.column('n_id',width=150)
    room_table.pack(fill=BOTH,expand=1)
    fetch_data()
    room_table.bind('<ButtonRelease-1>',get_cursor)
    
    


    




#-------------------------------------nurse-----------------------------------------------------------------------------------------------------------
def Nurse():
    def add_nurse():

        Id = n_id.get()
        name = n_name.get()
        mobile =n_mob.get()
        address = n_address.get()
        
        try:

            strr = 'insert into nurse values(%s,%s,%s,%s)'
            mycursor.execute(strr,(Id,name,mobile,address))
            con.commit()
            messagebox.showinfo('Notification','data added succesfully',parent=addroot)
            clear_nurse()
            fetch_data()
            
        except:
            messagebox.showerror('Notifications','Data is not added!',parent=addroot)
    
    def fetch_data():
        mycursor.execute("select * from nurse")
        rows = mycursor.fetchall()
        if len(rows)!=0:
            nurse_table.delete(*nurse_table.get_children())
            for row in rows:
                nurse_table.insert('',END,values=row)
            con.commit()
        

    def get_cursor(a):
        cursor_row = nurse_table.focus()
        contents = nurse_table.item(cursor_row)
        print(contents)
        row=contents['values']
        n_id.set(row[0])
        n_name.set(row[1])
        n_mob.set(row[2])
        n_address.set(row[3])


        
    def update_nurse():
        Id = n_id.get()
        name = n_name.get()
        mobile =n_mob.get()
        address = n_address.get()
        

        
        try:

            mycursor.execute("update nurse set n_name=%s,n_mob=%s,n_address=%s where n_id=%s ",(name,mobile,address,Id))
            con.commit()
            messagebox.showinfo('Notification','data updated succesfully',parent=addroot)
            fetch_data()
        except:
            messagebox.showerror('Notifications','Data is not updated!',parent=addroot)

            
            
        
    def delete_nurse():
        Id = n_id.get()
        name = n_name.get()
        mobile =n_mob.get()
        address = n_address.get()

        mycursor.execute("delete from nurse where n_id=%s",Id)
        con.commit()
        fetch_data()
        clear_nurse()

    def clear_nurse():
        n_id.set("")
        n_name.set("")
        n_mob.set("")
        n_address.set("")
        

    def search_nurse():

        Id = n_id.get()
        name = n_name.get()
        mobile =n_mob.get()
        address = n_address.get()
        search_by=n_search_by.get()
        search_txt=n_search_txt.get()

        if(search_by=='ID'):
            strr='select * from nurse where n_id=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                nurse_table.delete(*nurse_table.get_children())
                for row in rows:
                    nurse_table.insert('',END,values=row)
            con.commit()
        else:
            strr='select * from nurse where n_mob=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                nurse_table.delete(*nurse_table.get_children())
                for row in rows:
                    nurse_table.insert('',END,values=row)
            con.commit()
            

     #---------------nurse root-------------------------------------------------------------------------------   
    addroot = Toplevel(master=DATA_ENTRY)
    addroot.grab_set()
    addroot.geometry('1150x500+10+10')
    addroot.title('Hospital Management System')
    addroot.config(bg='DarkOrchid1')
    addroot.iconbitmap('hmsicon.ico')
    addroot.resizable(False,False)

    title_lable = Label(addroot,text='NURSE ENTRY',width=16,font=('arial',16,'italic bold'),bg='DarkOrchid1')
    title_lable.place(x=400,y=10)
     #----------------------manage frame-----------------------------------
    manage_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    manage_frame.place(x=20,y=50,width=450,height=400)

    id_lable = Label(manage_frame,text='ID:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    id_lable.place(x=10,y=10)
    
    name_lable = Label(manage_frame,text='NAME:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    name_lable.place(x=10,y=70)

    mobile_lable = Label(manage_frame,text='MOBILE:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    mobile_lable.place(x=10,y=130)

    address_lable = Label(manage_frame,text='ADDRESS:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    address_lable.place(x=10,y=190)

    
    n_id = StringVar()
    n_name = StringVar()
    n_mob = StringVar()
    n_address = StringVar()
    n_search_by = StringVar()
    n_search_txt = StringVar()



    id_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=n_id)
    id_entry.place(x=200,y=10)

    name_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=n_name)
    name_entry.place(x=200,y=70)

    mobile_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=n_mob)
    mobile_entry.place(x=200,y=130)

    address_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=n_address)
    address_entry.place(x=200,y=190)

    

    btn_frame=Frame(manage_frame,bd=5,relief=RIDGE,bg='white')
    btn_frame.place(x=5,y=300,width=425,height=50)

    add_doctorbtn = Button(btn_frame,text='ADD',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=add_nurse)
    add_doctorbtn.pack(side=LEFT,expand=True)

    update_doctorbtn = Button(btn_frame,text='UPDATE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=update_nurse)
    update_doctorbtn.pack(side=LEFT,expand=True)

    delete_doctorbtn = Button(btn_frame,text='DELETE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=delete_nurse)
    delete_doctorbtn.pack(side=LEFT,expand=True)

    clear_doctorbtn = Button(btn_frame,text='CLEAR',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=clear_nurse)
    clear_doctorbtn.pack(side=LEFT,expand=True)

    #--------------------detail frame----------------------------------------------------------

    detail_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    detail_frame.place(x=485,y=50,width=650,height=400)

    search_lable = Label(detail_frame,text='search by',width=10,font=('arial',10,'italic bold'),bg='RoyalBlue1')
    search_lable.place(x=10,y=10)

    search_combo = ttk.Combobox(detail_frame,font=('roman',10,'bold'),state='readonly',textvariable=n_search_by)
    search_combo['values']=("ID","MOBILE")
    search_combo.place(x=105,y=10)

    search_txt = Entry(detail_frame,font=('roman',11,'bold'),bd=5,textvariable=n_search_txt)
    search_txt.place(x=255,y=10)
    
    search_doctorbtn = Button(detail_frame,text='SEARCH',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=search_nurse)
    search_doctorbtn.place(x=444,y=10)

    show_doctorbtn = Button(detail_frame,text='SHOW ALL',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=fetch_data)
    show_doctorbtn.place(x=545,y=10)

    #----------------------table frame-----------------------------------------

    table_frame = Frame(detail_frame,bg='white',relief=GROOVE,borderwidth=5)
    table_frame.place(x=5,y=50,width=630,height=330)
    scroll_x = Scrollbar(table_frame,orient=HORIZONTAL)
    scroll_y = Scrollbar(table_frame,orient=VERTICAL)

    nurse_table = ttk.Treeview(table_frame,columns=('n_id','n_name','n_mob','n_address'),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
    
    scroll_x.pack(side=BOTTOM,fill=X)
    scroll_y.pack(side=RIGHT,fill=Y)

    scroll_x.config(command=nurse_table.xview)
    scroll_y.config(command=nurse_table.yview)

    nurse_table.heading('n_id',text="ID")
    nurse_table.heading('n_name',text="NAME")
    nurse_table.heading('n_mob',text="MOBILE")
    nurse_table.heading('n_address',text="ADDRESS")
    nurse_table['show']='headings'

    nurse_table.column('n_id',width=100)
    nurse_table.column('n_name',width=200)
    nurse_table.column('n_mob',width=150)
    nurse_table.column('n_address',width=150)
    nurse_table.pack(fill=BOTH,expand=1)
    fetch_data()
    nurse_table.bind('<ButtonRelease-1>',get_cursor)
    
    



#------------------------bill----------------------------------------------------------------------------------------
def Bill():
    def add_entry():
        no = b_id.get()
        patient = p_id.get()
        date = time.strftime("%y-%m-%d")
        b_date.set(date)
        doctorcharge = d_charge.get()
        roomcharge = r_charge.get()
        nursecharge = n_charge.get()
        bill = int(doctorcharge)+int(roomcharge)+int(nursecharge)
        total_bill.set(bill)
        try:

           strr = 'insert into bill values(%s,%s,%s,%s,%s,%s,%s)'
           mycursor.execute(strr ,(no,patient,date,doctorcharge,roomcharge,nursecharge,bill))
           con.commit()
           messagebox.showinfo('Notification','data added succesfully',parent=addroot)
           clear_entry()
           fetch_data()
            
        except:
            messagebox.showerror('Notifications','Data is not added!',parent=addroot)
    
    def fetch_data():
        mycursor.execute("select * from bill")
        rows = mycursor.fetchall()
        if len(rows)!=0:
            bill_table.delete(*bill_table.get_children())
            for row in rows:
                bill_table.insert('',END,values=row)
            con.commit()
        

    def get_cursor(a):
        cursor_row = bill_table.focus()
        contents = bill_table.item(cursor_row)
        print(contents)
        row=contents['values']
        b_id.set(row[0])
        p_id.set(row[1])
        b_date.set(row[2])
        d_charge.set(row[3])
        r_charge.set(row[4])
        n_charge.set(row[5])
        total_bill.set(row[6])
        
    def update_entry():
        no = b_id.get()
        patient = p_id.get()
        date = time.strftime("%D-%M-%Y")
        doctorcharge = d_charge.get()
        roomcharge = r_charge.get()
        nursecharge = n_charge.get()
        bill = total_bill.get()
        
        try:

            mycursor.execute("update bill set p_id=%s,b_date=%s,d_charge=%s,r_charge=%s,n_charge=%s,total_bill=%s where b_id=%s ",(no,date,doctorcharge,roomcharge,nursecharge,bill))
            con.commit()
            messagebox.showinfo('Notification','data updated succesfully',parent=addroot)
            fetch_data()
        except:
            messagebox.showerror('Notifications','Data is not updated!',parent=addroot)
        
            
    def delete_entry():
        no = b_id.get()
        patient = p_id.get()
        date = time.strftime("%D-%M-%Y")
        doctorcharge = d_charge.get()
        roomcharge = r_charge.get()
        nursecharge = n_charge.get()
        bill = total_bill.get()

        mycursor.execute("delete from bill where b_id=%s",no)
        con.commit()
        fetch_data()
        clear_entry()

    def clear_entry():
        b_id.set("")
        p_id.set("")
        b_date.set("")
        d_charge.set("")
        r_charge.set("")
        n_charge.set("")
        total_bill.set("")
        

    def search_record():

        no = b_id.get()
        patient = p_id.get()
        date = b_date.get()
        doctorcharge = d_charge.get()
        roomcharge = r_charge.get()
        nursecharge = n_charge.get()
        bill = total_bill.get()
        search_by= b_search_by.get()
        search_txt= b_search_txt.get()

        if(search_by=='RECORD NO'):
            strr='select * from bill where b_id=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                bill_table.delete(*bill_table.get_children())
                for row in rows:
                    bill_table.insert('',END,values=row)
            con.commit()
        elif(search_by=='DATE'):
            strr='select * from bill where b_date=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                bill_table.delete(*bill_table.get_children())
                for row in rows:
                    bill_table.insert('',END,values=row)
            con.commit()
        else:
            strr='select * from bill where p_id=%s'
            mycursor.execute(strr,search_txt)
            rows = mycursor.fetchall()
            if len(rows)!=0:
                bill_table.delete(*bill_table.get_children())
                for row in rows:
                    bill_table.insert('',END,values=row)
            con.commit()
        
    #-------------------------BILL--------------------------------------------      
    addroot = Toplevel(master=DATA_ENTRY)
    addroot.grab_set()
    addroot.geometry('1350x700+10+10')
    addroot.title('Hospital Management System')
    addroot.config(bg='DarkOrchid1')
    addroot.iconbitmap('hmsicon.ico')
    addroot.resizable(False,False)

    title_lable = Label(addroot,text='BILL ENTRY',width=16,font=('arial',16,'italic bold'),bg='DarkOrchid1')
    title_lable.place(x=400,y=10)
#----------------------manage frame-------------------------------------------------------------------------------------
    manage_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    manage_frame.place(x=20,y=90,width=450,height=560)

    id_lable = Label(manage_frame,text='ID:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    id_lable.place(x=10,y=10)
    
    p_lable = Label(manage_frame,text='PATIENT ID:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    p_lable.place(x=10,y=70)

    date_lable = Label(manage_frame,text='DATE:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    date_lable.place(x=10,y=130)

    d_lable = Label(manage_frame,text='DOCTORCHARGE:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    d_lable.place(x=10,y=190)

    r_lable = Label(manage_frame,text='ROOM CHARGE:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    r_lable.place(x=10,y=250)

    n_lable = Label(manage_frame,text='NURSE CHARGE:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    n_lable.place(x=10,y=310)

    bill_lable = Label(manage_frame,text='TOTAL BILL:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    bill_lable.place(x=10,y=370)

    
    b_id = StringVar()
    p_id = StringVar()
    b_date = StringVar()
    d_charge = StringVar()
    r_charge = StringVar()
    n_charge = StringVar()
    total_bill = StringVar()
    b_search_by = StringVar()
    b_search_txt = StringVar()



    id_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=b_id)
    id_entry.place(x=200,y=10)

    p_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=p_id)
    p_entry.place(x=200,y=70)

    date_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=b_date)
    date_entry.place(x=200,y=130)

    d_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=d_charge)
    d_entry.place(x=200,y=190)

    r_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=r_charge)
    r_entry.place(x=200,y=250)

    n_entry = Entry(manage_frame,font=('roman',15,'bold'),bd=5,textvariable=n_charge)
    n_entry.place(x=200,y=310)

    bill_entry = Entry(manage_frame,font=("roman",15,'bold'),bd=5,textvariable=total_bill)
    bill_entry.place(x=200,y=360)


    btn_frame=Frame(manage_frame,bd=5,relief=RIDGE,bg='white')
    btn_frame.place(x=5,y=469,width=425,height=50)

    add_doctorbtn = Button(btn_frame,text='ADD',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=add_entry)
    add_doctorbtn.pack(side=LEFT,expand=True)

    update_doctorbtn = Button(btn_frame,text='UPDATE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=update_entry)
    update_doctorbtn.pack(side=LEFT,expand=True)

    delete_doctorbtn = Button(btn_frame,text='DELETE',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=delete_entry)
    delete_doctorbtn.pack(side=LEFT,expand=True)

    clear_doctorbtn = Button(btn_frame,text='CLEAR',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=clear_entry)
    clear_doctorbtn.pack(side=LEFT,expand=True)

#--------------------detail frame----------------------------------------------------------

    detail_frame = Frame(addroot,bg='white',relief=GROOVE,borderwidth=5)
    detail_frame.place(x=500,y=90,width=800,height=560)

    search_lable = Label(detail_frame,text='search by',width=10,font=('arial',11,'italic bold'),bg='RoyalBlue1')
    search_lable.place(x=10,y=10)

    search_combo = ttk.Combobox(detail_frame,font=('roman',11,'bold'),state='readonly',textvariable=b_search_by)
    search_combo['values']=("RECORD NO","PATIENT ID","DATE")
    search_combo.place(x=130,y=10)

    search_txt = Entry(detail_frame,font=('roman',12,'bold'),bd=5,textvariable=b_search_txt)
    search_txt.place(x=300,y=10)
    
    search_doctorbtn = Button(detail_frame,text='SEARCH',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=search_record)
    search_doctorbtn.place(x=500,y=10)

    show_doctorbtn = Button(detail_frame,text='SHOW ALL',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=fetch_data)
    show_doctorbtn.place(x=620,y=10)

    #----------------------table frame-----------------------------------------

    table_frame = Frame(detail_frame,bg='white',relief=GROOVE,borderwidth=5)
    table_frame.place(x=10,y=50,width=760,height=500)
    scroll_x = Scrollbar(table_frame,orient=HORIZONTAL)
    scroll_y = Scrollbar(table_frame,orient=VERTICAL)

    bill_table = ttk.Treeview(table_frame,columns=('b_id','p_id','b_date','d_charge','r_charge','n_charge','total_bill'),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
    
    scroll_x.pack(side=BOTTOM,fill=X)
    scroll_y.pack(side=RIGHT,fill=Y)

    scroll_x.config(command=bill_table.xview)
    scroll_y.config(command=bill_table.yview)

    bill_table.heading('b_id',text="BILL NO")
    bill_table.heading('p_id',text="PATIENT ID")
    bill_table.heading('b_date',text="DATE")
    bill_table.heading('d_charge',text="DOCTOR CHARGE")
    bill_table.heading('r_charge',text="ROOM CHARGE")
    bill_table.heading('n_charge',text="NURSE CHARGE")
    bill_table.heading('total_bill',text="TOTAL BILL")
    bill_table['show']='headings'

    bill_table.column('b_id',width=100)
    bill_table.column('p_id',width=200)
    bill_table.column('b_date',width=150)
    bill_table.column('d_charge',width=150)
    bill_table.column('r_charge',width=100)
    bill_table.column('n_charge',width=150)
    bill_table.column('total_bill',width=200)
    bill_table.pack(fill=BOTH,expand=1)
    fetch_data()
    bill_table.bind('<ButtonRelease-1>',get_cursor)
    
    
#----------------------------exit----------------------------------------------------------------------

def exitfun():
    res = messagebox.askyesnocancel('Notification',"Do you want to exit?")
    if(res==True):
        root.destroy()




#------------------------------------------root----------------------------------------------
from tkinter import*
from tkinter import Toplevel,messagebox
from tkinter.ttk import Treeview
from tkinter import ttk
import pymysql
import mysql.connector
import time
from datetime import datetime
from datetime import date

root = Tk()
root.title("HOSPITAL MANAGEMENT SYSTEM")
root.config(bg='DarkOrchid1')
root.geometry('1170x600+90+30')
root.iconbitmap('hmsicon.ico')
root.resizable('false','false')

#connection of database--------------------------------------------------------------------------------------------------
def connectdb():
    
    def submit():
        global con,mycursor
        host = hostval.get()
        user = userval.get()
        password = passwordval.get()
        

        try:
           con = pymysql.connect(host=host,user=user,password=password)
           mycursor = con.cursor()
        except:
           messagebox.showerror('Notifications','Data is incorrect')
           return
        try:
            strr = 'create database hospital'
            mycursor.execute(strr)
            strr = 'use hospital'
            mycursor.execute(strr)
            strr = 'create table doctor(d_id varchar(30) NOT NULL,d_name varchar(40),d_qualification varchar(40),department varchar(40),d_mob varchar(40),d_email varchar(40),d_address varchar(40),d_gender varchar(40),PRIMARY KEY(d_id))'
            mycursor.execute(strr)
            strr = 'create table patient(p_id varchar(30) NOT NULL,p_name varchar(40),p_address varchar(40),p_mob varchar(40),p_disease varchar(40),p_dob varchar(20),p_age varchar(10),d_id varchar(30),PRIMARY KEY(p_id),FOREIGN KEY(d_id) REFERENCES doctor(d_id))'
            mycursor.execute(strr)
            strr = 'create table nurse(n_id varchar(30) NOT NULL,n_name varchar(40),n_mob varchar(40),n_address varchar(40),PRIMARY KEY(n_id))'
            mycursor.execute(strr)
            strr = 'create table room(r_no varchar(10) NOT NULL,r_type varchar(40),r_status varchar(40),n_id varchar(30),PRIMARY KEY(r_no),FOREIGN KEY(n_id) REFERENCES nurse(n_id))'
            mycursor.execute(strr)
            strr = 'create table inpatient(In_id varchar(30) NOT NULL,p_id varchar(30),date_of_admission varchar(20),date_of_discharge varchar(20),r_no varchar(10),PRIMARY KEY(In_id),FOREIGN KEY(p_id) REFERENCES patient(p_id),FOREIGN KEY(r_no) REFERENCES room(r_no))'
            mycursor.execute(strr)
            strr = 'create table outpatient(O_id varchar(30) NOT NULL,p_id varchar(30),date_of_examination varchar(20),PRIMARY KEY(O_id),FOREIGN KEY(p_id) REFERENCES patient(p_id))'
            mycursor.execute(strr)
            strr = 'create table bill(b_id varchar(30) NOT NULL,p_id varchar(30),b_date DATE,r_charge varchar(20),d_charge varchar(20),n_charge varchar(20),total_bill varchar(20),PRIMARY KEY(b_id),FOREIGN KEY(p_id) REFERENCES patient(p_id))'
            mycursor.execute(strr)
            messagebox.showinfo('Notification','DATABASE is created and now you are connected to database',parent=dbroot)
        except:
            strr = 'use hospital'
            mycursor.execute(strr)
            messagebox.showinfo('Notification','you are connected to database',parent=dbroot)
            
    hostval= StringVar()
    userval= StringVar()
    passwordval= StringVar()

    dbroot = Toplevel()
    dbroot.grab_set()
    dbroot.geometry('470x250+800+230')
    dbroot.iconbitmap('hmsicon.ico')
    dbroot.resizable(False,False)
    dbroot.config(bg='white')

    host_lable = Label(dbroot,text='HOST:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    host_lable.place(x=10,y=10)
    
    user_lable = Label(dbroot,text='USER:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    user_lable.place(x=10,y=70)

    password_lable = Label(dbroot,text='PASSWORD:',width=14,font=('arial',15,'italic bold'),bg='RoyalBlue1')
    password_lable.place(x=10,y=130)

    submitbtn = Button(dbroot,text='SUBMIT',width=10,font=('chillar',10,'bold'),bd=3,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=submit)
    submitbtn.place(x=200,y=190)

    host_entry = Entry(dbroot,font=('roman',15,'bold'),bd=5,textvariable=hostval)
    host_entry.place(x=250,y=10)

    user_entry = Entry(dbroot,font=('roman',15,'bold'),bd=5,textvariable=userval)
    user_entry.place(x=250,y=70)

    password_entry = Entry(dbroot,font=('roman',15,'bold'),bd=5,textvariable=passwordval)
    password_entry.place(x=250,y=130)

#-------------------------------------------------------------------------------------------------------------------------------------------------

#frames
DATA_ENTRY = Frame(root,bg='SlateGray2',relief=GROOVE,borderwidth=5)
DATA_ENTRY.place(x=35,y=65,width=1100,height=500)

#Data_Entery_Frame
frontlable = Label(DATA_ENTRY,text='----Select Entry----',width=10,font=('arial',20,'italic bold'),bg='SlateGray2')
frontlable.place(x=370,y=10,width=400,height=50)

doctorbtn = Button(DATA_ENTRY,text='Doctor',width=24,font=('chillar',15,'bold'),bd=6,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=Doctor)
doctorbtn.place(x=100,y=90,width=210,height=50)

patientbtn = Button(DATA_ENTRY,text='Patient',width=24,font=('chillar',15,'bold'),bd=6,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=Patient)
patientbtn.place(x=750,y=90,width=210,height=50)

inpatientbtn = Button(DATA_ENTRY,text='InPatient',width=24,font=('chillar',15,'bold'),bd=6,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=Inpatient)
inpatientbtn.place(x=750,y=200,width=210,height=50)

outpatientbtn = Button(DATA_ENTRY,text='OutPatient',width=24,font=('chillar',15,'bold'),bd=6,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=Outpatient)
outpatientbtn.place(x=750,y=310,width=210,height=50)

roombtn = Button(DATA_ENTRY,text='Room',width=24,font=('chillar',15,'bold'),bd=6,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=Room)
roombtn.place(x=100,y=310,width=210,height=50)

nursebtn = Button(DATA_ENTRY,text='Nurse',width=24,font=('chillar',15,'bold'),bd=6,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=Nurse)
nursebtn.place(x=100,y=200,width=210,height=50)

billbtn = Button(DATA_ENTRY,text='Bill',width=24,font=('chillar',15,'bold'),bd=6,bg='RoyalBlue1',activebackground='blue',relief=RIDGE,activeforeground='white',command=Bill)
billbtn.place(x=100,y=420,width=210,height=50)

exitbtn = Button(DATA_ENTRY,text='EXIT',width=24,font=('chillar',15,'bold'),bd=6,bg='hot pink',activebackground='blue4',relief=RIDGE,activeforeground='white',command=exitfun)
exitbtn.place(x=750,y=420,width=210,height=50)







#time_function
def tick():
    time_string = time.strftime("%H:%M:%S")
    date_string = time.strftime("%D")
    clock.config(text='Date:'+date_string+"\n"+"Time:"+time_string)
    clock.after(200,tick)

#Labels
ss= "Welcome To Hospital Management System"

SliderLabel = Label(root,text=ss,font=('chiller',25,'bold'),relief=RIDGE,borderwidth=5,width=40,bg='cyan')
SliderLabel.place(x=260,y=0)


clock = Label(root,font=('times',14,'bold'),relief=RIDGE,borderwidth=4,bg='hot pink')
clock.place(x=0,y=0)
tick()


connectbtn = Button(root,text='Connect to database',width=19,font=('chiilar',15,'italic bold'),relief=RIDGE,borderwidth=4,bg='hot pink',command=connectdb)
connectbtn.place(x=900,y=0)




root.mainloop()
